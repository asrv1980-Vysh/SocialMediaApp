package com.example.socialmediaapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        EditText etName = findViewById(R.id.etProfileName);
        EditText etBio = findViewById(R.id.etBio);

        Button btnEdit = findViewById(R.id.btnEditProfile);
        Button btnSave = findViewById(R.id.btnSaveProfile);

        btnEdit.setOnClickListener(v -> {
            etName.setEnabled(true);
            etBio.setEnabled(true);

            Toast.makeText(this,
                    "Edit Profile Enabled",
                    Toast.LENGTH_SHORT).show();
        });

        btnSave.setOnClickListener(v -> {

            if (etName.getText().toString().trim().isEmpty()) {

                Toast.makeText(this,
                        "Please enter your name",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Profile Updated Successfully",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}