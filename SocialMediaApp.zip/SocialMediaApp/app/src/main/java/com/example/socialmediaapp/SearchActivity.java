package com.example.socialmediaapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        EditText etSearchUser = findViewById(R.id.etSearchUser);
        Button btnSearchUser = findViewById(R.id.btnSearchUser);
        TextView tvSearchResult = findViewById(R.id.tvSearchResult);

        btnSearchUser.setOnClickListener(v -> {

            String username =
                    etSearchUser.getText().toString().trim();

            if (username.isEmpty()) {

                tvSearchResult.setText(
                        "Please enter a username");

            } else {

                tvSearchResult.setText(
                        "User found: @" + username);
            }
        });
    }
}