package com.example.socialmediaapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreatePostActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);

        EditText etCaption = findViewById(R.id.etCaption);
        Button btnUpload = findViewById(R.id.btnUpload);
        Button btnPublish = findViewById(R.id.btnPublish);

        btnUpload.setOnClickListener(v ->
                Toast.makeText(this,
                        "Media Selected",
                        Toast.LENGTH_SHORT).show());

        btnPublish.setOnClickListener(v -> {

            if (etCaption.getText().toString().trim().isEmpty()) {

                Toast.makeText(this,
                        "Please enter a caption",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Post Published Successfully",
                        Toast.LENGTH_SHORT).show();

                finish();
            }
        });
    }
}