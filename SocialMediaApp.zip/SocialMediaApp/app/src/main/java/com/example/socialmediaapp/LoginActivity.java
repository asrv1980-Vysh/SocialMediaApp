package com.example.socialmediaapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnSignup = findViewById(R.id.btnSignup);

        btnLogin.setOnClickListener(v -> {

            if (etEmail.getText().toString().trim().isEmpty()
                    || etPassword.getText().toString().trim().isEmpty()) {

                Toast.makeText(this,
                        "Please enter all details",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Login Successful",
                        Toast.LENGTH_SHORT).show();

                startActivity(new Intent(
                        LoginActivity.this,
                        HomeActivity.class));
            }
        });

        btnSignup.setOnClickListener(v ->
                startActivity(new Intent(
                        LoginActivity.this,
                        SignupActivity.class)));
    }
}