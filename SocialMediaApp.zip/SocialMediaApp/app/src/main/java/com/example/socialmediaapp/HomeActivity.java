package com.example.socialmediaapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button btnSearch = findViewById(R.id.btnSearch);
        Button btnCreatePost = findViewById(R.id.btnCreatePost);
        Button btnLike = findViewById(R.id.btnLike);
        Button btnComment = findViewById(R.id.btnComment);
        Button btnFollow = findViewById(R.id.btnFollow);
        Button btnProfile = findViewById(R.id.btnProfile);
        Button btnLogout = findViewById(R.id.btnLogout);

        btnSearch.setOnClickListener(v ->
                startActivity(new Intent(this,
                        SearchActivity.class)));

        btnCreatePost.setOnClickListener(v ->
                startActivity(new Intent(this,
                        CreatePostActivity.class)));

        btnLike.setOnClickListener(v ->
                Toast.makeText(this,
                        "Post Liked ❤️",
                        Toast.LENGTH_SHORT).show());

        btnComment.setOnClickListener(v ->
                Toast.makeText(this,
                        "Comment Added",
                        Toast.LENGTH_SHORT).show());

        btnFollow.setOnClickListener(v ->
                Toast.makeText(this,
                        "Following",
                        Toast.LENGTH_SHORT).show());

        btnProfile.setOnClickListener(v ->
                startActivity(new Intent(this,
                        ProfileActivity.class)));

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(this,
                    MainActivity.class);

            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        });
    }
}