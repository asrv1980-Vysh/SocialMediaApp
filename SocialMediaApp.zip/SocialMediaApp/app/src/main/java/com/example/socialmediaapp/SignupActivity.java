package com.example.socialmediaapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etSignupEmail);
        EditText etPassword = findViewById(R.id.etSignupPassword);

        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnCreateAccount.setOnClickListener(v -> {

            if (etName.getText().toString().trim().isEmpty()
                    || etEmail.getText().toString().trim().isEmpty()
                    || etPassword.getText().toString().trim().isEmpty()) {

                Toast.makeText(this,
                        "Please enter all details",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Account Created Successfully",
                        Toast.LENGTH_SHORT).show();

                startActivity(new Intent(
                        SignupActivity.this,
                        LoginActivity.class));
            }
        });
    }
}